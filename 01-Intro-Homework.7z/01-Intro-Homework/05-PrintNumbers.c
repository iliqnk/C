#include <stdio.h>

/*
 * Write a program to print the numbers 1, 101 and 1001, 
 * each at a separate line.
 */
int main() 
{
    int a = 1;
    int b = 101;
    int c = 1001;
    
    printf("%d\n%d\n%d", a, b, c);
    
    return 0;
}

