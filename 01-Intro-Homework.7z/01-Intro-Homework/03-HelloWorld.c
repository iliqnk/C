#include <stdio.h>
/*
 * Create, compile and run a "Hello, C" console application.
 */
int main()
{
    printf("Hello, C!");
    return 0;
}

