#include <stdio.h>

/*
 * Modify the previous program to print your name.
 */
int main() 
{
    printf("My name is Bob.");
    return 0;
}

