#include <stdio.h>
/*
 * Create console application that prints your first and last name, 
 * each at a separate line.
 */
int main() {
    printf("Bob\nDylan");    
    return 0;
}

