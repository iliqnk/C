#include <stdio.h>

/*
 * Declare a variable called isFemale and assign an appropriate value
 *  corresponding to your gender. Print it on the console.
 */
int main() 
{
    int isFemale = 1;
    
    if (isFemale)
    {
        printf("true");
    }
    else
    {
        printf("false");
    }
    
    return 0;
}

