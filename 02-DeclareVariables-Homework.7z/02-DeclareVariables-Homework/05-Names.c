#include <stdio.h>

/*
 * Declare two string (char array) variables holding your first name
 *  and last name. Print them in the console (mind adding an interval 
 * between them).
 */
int main() 
{
    char *firstName = "Mark";
    char *secondName = "Twain";
    
    printf("%s %s", firstName, secondName);
    
    return 0;
}

